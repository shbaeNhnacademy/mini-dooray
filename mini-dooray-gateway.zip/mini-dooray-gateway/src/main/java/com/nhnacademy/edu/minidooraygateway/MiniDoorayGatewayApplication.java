package com.nhnacademy.edu.minidooraygateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniDoorayGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MiniDoorayGatewayApplication.class, args);
	}

}
