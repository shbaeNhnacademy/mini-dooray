package com.nhnacademy.edu.minidoorayaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniDoorayAccountApplicationTests {

	@Test
	void contextLoads() {
	}

}
